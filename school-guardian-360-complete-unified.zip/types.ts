// This file is intentionally left blank. The content has been moved to src/types.ts to match component import paths.
