# Deployment Guide: School Guardian 360

This guide provides instructions for deploying the School Guardian 360 application, which consists of two main parts: the Supabase backend and the React frontend.

---

## Part 1: Supabase Backend Setup

Supabase provides the database, authentication, and backend services.

### Step 1: Create a Supabase Project

1.  Go to [supabase.com](https://supabase.com/) and create an account or log in.
2.  Create a new project. Choose a strong database password and store it securely.
3.  Wait for the project to be provisioned.

### Step 2: Get API Credentials

1.  Once your project is ready, navigate to **Project Settings** (the gear icon in the left sidebar).
2.  Click on **API**.
3.  You will find your **Project URL** and your `anon` **public** key.
4.  You will need these for your frontend application's environment variables. You will add these to your `.env` file in Part 2.

### Step 3: Set Up the Database Schema

This application is designed to guide you through the database setup process.

1.  After configuring your frontend with the Supabase credentials (see Part 2), run the application locally (`npm run dev`).
2.  If the database is not yet configured, the application will display a **"Critical Application Error"** page specifically for this purpose.
3.  On this error page, click the **"Show Required SQL Schema"** button.
4.  Click the **"Copy to Clipboard"** button to copy the entire database script.
5.  In your Supabase project dashboard, navigate to the **SQL Editor**.
6.  Paste the copied SQL content into the query window and click **RUN**.

This script will create all necessary tables, roles, functions, and security policies. It also pre-populates essential data, like user roles.

### Step 4: Enable and Configure Row-Level Security (RLS)

RLS is the core of your data security. It ensures users can only access the data they are permitted to see.

1.  In the Supabase dashboard, navigate to **Authentication** (the user icon).
2.  Click on **Policies**.
3.  You will see a list of your tables. You must **enable RLS** for each of the following tables by clicking the toggle next to its name:
    *   `academic_classes`
    *   `academic_class_students`
    *   `announcements`
    *   `arms`
    *   `assessments`
    *   `assessment_scores`
    *   `attendance_records`
    *   `attendance_schedules`
    *   `audit_log`
    *   `calendar_events`
    *   `class_group_members`
    *   `class_groups`
    *   `class_sections`
    *   `class_subjects`
    *   `classes`
    *   `communications_audit`
    *   `curriculum`
    *   `curriculum_weeks`
    *   `grading_scheme_rules`
    *   `grading_schemes`
    *   `inventory_items`
    *   `lesson_plan_coverage_votes`
    *   `lesson_plans`
    *   `living_policy_snippets`
    *   `notifications`
    *   `positive_behavior`
    *   `quiz_mc_option_counts`
    *   `quiz_questions`
    *   `quiz_responses`
    *   `quizzes`
    *   `report_comments`
    *   `reports`
    *   `reward_redemptions`
    *   `rewards_store_items`
    *   `roles`
    *   `schools`
    *   `school_config`
    *   `score_entries`
    *   `sip_logs`
    *   `staff_awards`
    *   `student_awards`
    *   `student_entity_enrollments`
    *   `student_intervention_plans`
    *   `student_profiles`
    *   `student_subject_choices`
    *   `student_term_reports`
    *   `student_term_report_subjects`
    *   `student_term_report_traits`
    *   `students`
    *   `subjects`
    *   `tasks`
    *   `team_assignments`
    *   `team_feedback`
    *   `teams`
    *   `teacher_rating_policies`
    *   `teacher_rating_weekly`
    *   `teacher_ratings`
    *   `teaching_assignments`
    *   `teaching_entities`
    *   `terms`
    *   `user_profiles`
    *   `user_role_assignments`
4.  The policies themselves were already created when you ran the SQL script. By enabling RLS, you are activating these policies.

### Step 5: Create Public Storage Buckets & Policies (CRITICAL)

This step is required for image uploads to work correctly.

1.  In the Supabase dashboard, navigate to **Storage** (the file cabinet icon).
2.  Click the **"New bucket"** button.
3.  Enter `report_images` as the bucket name.
4.  Toggle the switch for **"Public bucket"** to make it ON.
5.  Click **"Create bucket"**.
6.  Repeat the process to create a second bucket:
    *   Enter `avatars` as the bucket name.
    *   Toggle the switch for **"Public bucket"** to make it ON.
    *   Click **"Create bucket"**.
7.  **IMPORTANT**: You must add security policies to both buckets. Go to `Storage` -> `Policies`. Create new policies for each bucket that match the `STORAGE POLICIES` section at the bottom of the SQL schema script you ran in Step 3.

### Step 6: Schedule Automated Jobs (Cron)

The application relies on periodic jobs to aggregate data and send reminders.

1.  In your Supabase project dashboard, navigate to **SQL Editor**.
2.  Click on **Cron Jobs**.
3.  Create three new jobs:
    *   **Job 1: Compute Weekly Ratings**
        *   **Name:** `Compute Weekly Teacher Ratings`
        *   **Schedule:** `0 0 * * *` (This runs daily at midnight UTC)
        *   **Function:** `SELECT public.compute_teacher_rating_week_current();`
    *   **Job 2: Refresh Public Leaderboard**
        *   **Name:** `Refresh Public Leaderboard`
        *   **Schedule:** `5 0 * * *` (This runs daily at 00:05 UTC, right after the first job)
        *   **Function:** `SELECT public.refresh_public_leaderboard_mv();`
    *   **Job 3: Check Task Reminders**
        *   **Name:** `Check Task Reminders`
        *   **Schedule:** `*/5 * * * *` (This runs every 5 minutes)
        *   **Function:** `SELECT public.check_task_reminders();`

Your Supabase backend is now configured and ready. Refresh the application in your browser.

---

## Part 2: Frontend Deployment

These instructions assume you are deploying a production build of the React application to any static hosting provider.

### Step 1: Build the Application for Production

Before deploying, you need to create an optimized bundle of your application.

1.  Create a file named `.env` in the root of your project (you can copy `.env.example`).
2.  Fill this `.env` file with your **production** Supabase URL, Supabase anon key, and your Google Gemini API key. This is a critical step to ensure your deployed app connects to your production backend. All variables must be prefixed with `VITE_`.
3.  From your project's root directory, run the build command:
    ```bash
    npm run build
    ```
4.  This command will create a new folder named `dist` in your project root. This folder contains the static HTML, CSS, and JavaScript files that make up your application.

### Step 2: Upload Files to Hosting Provider

1.  Log in to your hosting provider (e.g., Vercel, Netlify, AWS S3, Hostinger).
2.  Follow their instructions for deploying a static site.
3.  You will typically drag-and-drop the **contents** of the `dist` folder or connect your Git repository and point the build command to `npm run build` and the publish directory to `dist`.

### Step 3: Final Checks

1.  Visit your domain name in a web browser. The School Guardian 360 login page should appear.
2.  Test the sign-up and login functionality to ensure it is correctly communicating with your Supabase backend.

Your application is now live!