
import React from 'react';

/**
 * @deprecated This component has been replaced by LessonPlanEditorModal.tsx
 */
const LessonPlanGeneratorModal: React.FC = () => {
  return null;
};

export default LessonPlanGeneratorModal;
