
// This file is deprecated. Please use src/components/SuperAdminConsole.tsx
export default () => null;
